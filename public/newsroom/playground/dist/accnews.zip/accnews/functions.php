<?php
/**
 * Sample Newsroom theme setup.
 *
 * The theme has no JavaScript of its own and loads no third party resources.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The name the site shows to visitors.
 */
function accnews_site_name(): string {
	return 'Sample Newsroom';
}

add_action(
	'after_setup_theme',
	static function () {
		add_editor_style( 'style.css' );
		add_theme_support( 'responsive-embeds' );
	}
);

add_action(
	'wp_enqueue_scripts',
	static function () {
		$file = get_theme_file_path( 'style.css' );
		wp_enqueue_style( 'accnews', get_theme_file_uri( 'style.css' ), array(), (string) filemtime( $file ) );
	}
);

// The two font files are asked for before the stylesheet is read, so the first screen is set in
// its own typefaces sooner. The faces are declared in theme.json with font-display: swap.
add_action(
	'wp_head',
	static function () {
		foreach ( array( 'newsreader-var.woff2', 'roboto-var.woff2' ) as $font ) {
			printf(
				"<link rel=\"preload\" href=\"%s\" as=\"font\" type=\"font/woff2\" crossorigin>\n",
				esc_url( get_theme_file_uri( 'assets/fonts/' . $font ) )
			);
		}
	},
	1
);

/**
 * The point of a photograph that has to stay in view when it is cropped, as a CSS position
 * ("x% y%", measured from the left and from the top of the picture).
 *
 * The points are looked up by the name of the file, without its extension and without the
 * endings WordPress adds ("-scaled", "-1", "-e1699999999"), so they survive a new import of the
 * content. To add a photograph, add one line to the list with the name of its file. A photograph
 * that is not in the list is cropped around its centre. A custom field named "accnews_focus" on
 * the attachment takes precedence over the list, so a point can also be set without editing the
 * theme, and the list can be changed from a plugin through the "accnews_image_focus" filter.
 */
function accnews_image_focus( int $attachment_id ): string {
	if ( $attachment_id <= 0 ) {
		return '';
	}
	$focus = (array) apply_filters(
		'accnews_image_focus',
		array(
			// The engineer walks along the wall at the left of the tunnel.
			'linac4'       => '17% 50%',
			// The technician stands at the left, under the hanging magnet array.
			'lcls-undulator' => '30% 40%',
			// New photographs go here, one line each: 'name-of-the-file' => 'x% y%'.
		)
	);
	$point = (string) get_post_meta( $attachment_id, 'accnews_focus', true );
	if ( '' === $point ) {
		$file  = (string) get_attached_file( $attachment_id );
		$name  = preg_replace( '~\.[a-z0-9]+$~i', '', wp_basename( $file ) );
		$name  = preg_replace( '~(-scaled|-e\d{10,}|-\d{1,2})+$~', '', (string) $name );
		$point = (string) ( $focus[ $name ] ?? '' );
	}
	// Only a pair of percentages is passed on to the stylesheet.
	return preg_match( '~^\d{1,3}(\.\d+)?% \d{1,3}(\.\d+)?%$~', $point ) ? $point : '';
}

// Emoji detection, oEmbed discovery and generator tags add requests and bytes this site does not need.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

// The site is written in British English, whatever locale WordPress was installed with.
add_filter(
	'language_attributes',
	static function ( $output ) {
		if ( is_admin() ) {
			return $output;
		}
		if ( preg_match( '/\blang="[^"]*"/', (string) $output ) ) {
			return preg_replace( '/\blang="[^"]*"/', 'lang="en-GB"', (string) $output );
		}
		return trim( $output . ' lang="en-GB"' );
	}
);

// The browser tab carries the name of the site as visitors see it in the header.
add_filter(
	'document_title_parts',
	static function ( array $parts ) {
		if ( isset( $parts['site'] ) ) {
			$parts['site'] = accnews_site_name();
		}
		if ( is_front_page() || is_home() ) {
			$parts['title'] = accnews_site_name();
		}
		return $parts;
	}
);

add_action(
	'init',
	static function () {
		register_block_style( 'core/group', array( 'name' => 'brief', 'label' => __( 'In brief', 'accnews' ) ) );
		register_block_style( 'core/group', array( 'name' => 'note', 'label' => __( 'Editorial note', 'accnews' ) ) );

		register_block_pattern_category( 'accnews', array( 'label' => __( 'Sample Newsroom', 'accnews' ) ) );

		// The caption and credit of the featured image, so every photograph carries its author and licence.
		register_block_bindings_source(
			'accnews/image-credit',
			array(
				'label'              => __( 'Featured image credit', 'accnews' ),
				'uses_context'       => array( 'postId' ),
				'get_value_callback' => static function ( array $args, $block ) {
					$post_id = $block->context['postId'] ?? get_the_ID();
					$thumb   = $post_id ? get_post_thumbnail_id( $post_id ) : 0;
					return $thumb ? wp_kses_post( wp_get_attachment_caption( $thumb ) ) : '';
				},
			)
		);

		// A link that shares the current article on LinkedIn, with no script.
		register_block_bindings_source(
			'accnews/share-linkedin',
			array(
				'label'              => __( 'Share on LinkedIn', 'accnews' ),
				'uses_context'       => array( 'postId' ),
				'get_value_callback' => static function ( array $args, $block ) {
					$post_id = $block->context['postId'] ?? get_the_ID();
					return 'https://www.linkedin.com/sharing/share-offsite/?url=' . rawurlencode( (string) get_permalink( $post_id ) );
				},
			)
		);

		// Reading time, exposed through the Block Bindings API so editors can place it in any paragraph.
		register_block_bindings_source(
			'accnews/reading-time',
			array(
				'label'              => __( 'Reading time', 'accnews' ),
				'uses_context'       => array( 'postId' ),
				'get_value_callback' => static function ( array $args, $block ) {
					$post_id = $block->context['postId'] ?? get_the_ID();
					if ( ! $post_id ) {
						return '';
					}
					$words   = str_word_count( wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) ) );
					$minutes = max( 1, (int) ceil( $words / 230 ) );
					/* translators: %d: minutes */
					return sprintf( _n( '%d min read', '%d min read', $minutes, 'accnews' ), $minutes );
				},
			)
		);

		// The number of published articles, written out, so a heading never claims more than the site holds.
		register_block_bindings_source(
			'accnews/article-count',
			array(
				'label'              => __( 'Number of articles', 'accnews' ),
				'get_value_callback' => static function ( array $args ) {
					$count  = (int) wp_count_posts( 'post' )->publish;
					$words  = array( 'no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve' );
					$number = $words[ $count ] ?? (string) $count;
					$format = $args['format'] ?? '%s articles';
					if ( 1 === $count && ! empty( $args['singular'] ) ) {
						$format = $args['singular'];
					}
					return esc_html( ucfirst( sprintf( $format, $number ) ) );
				},
			)
		);
	}
);

/**
 * Description and Open Graph tags, so a link shared on LinkedIn carries a proper title and summary.
 */
add_action(
	'wp_head',
	static function () {
		$title = wp_get_document_title();
		$desc  = get_bloginfo( 'description' );
		$type  = 'website';
		$url   = home_url( '/' );

		if ( is_singular() ) {
			$post = get_queried_object();
			$desc = wp_strip_all_tags( get_the_excerpt( $post ) );
			$url  = get_permalink( $post );
			$type = is_singular( 'post' ) ? 'article' : 'website';
		}

		// The site icon is the mark of the masthead, a block cut in two by the path of a beam. It is
		// inlined, so it costs no request. It is blue on a light tab and white on a dark one, and the
		// white ground keeps the path visible where a browser does not tell the two apart.
		$icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
			. '<style>.g{fill:#fff}.m{fill:#0033A0}@media (prefers-color-scheme:dark){.g{fill:none}.m{fill:#fff}}</style>'
			. '<path class="g" d="M0,0H24V24H0Z"/>'
			. '<path class="m" d="M0,0H10.023A9.632,9.632 0 0 0 10.939,12.561A7.339,7.339 0 0 1 9.597,24H0ZM24,24H13.986A10.339,10.339 0 0 0 13.061,10.439A6.632,6.632 0 0 1 14.446,0H24Z"/>'
			. '</svg>';
		printf( "<link rel=\"icon\" type=\"image/svg+xml\" href=\"data:image/svg+xml,%s\">\n", rawurlencode( $icon ) );
		printf( "<meta name=\"description\" content=\"%s\">\n", esc_attr( $desc ) );
		printf( "<meta property=\"og:title\" content=\"%s\">\n", esc_attr( $title ) );
		printf( "<meta property=\"og:description\" content=\"%s\">\n", esc_attr( $desc ) );
		printf( "<meta property=\"og:type\" content=\"%s\">\n", esc_attr( $type ) );
		printf( "<meta property=\"og:url\" content=\"%s\">\n", esc_url( $url ) );
		printf( "<meta property=\"og:site_name\" content=\"%s\">\n", esc_attr( accnews_site_name() ) );
		echo '<meta property="og:locale" content="en_GB">' . "\n";
		// The bar of the browser takes the blue of the masthead on a phone.
		echo '<meta name="theme-color" content="#0033A0">' . "\n";
		$image_id = is_singular() ? get_post_thumbnail_id( get_queried_object_id() ) : 0;
		if ( ! $image_id ) {
			$latest   = get_posts( array( 'numberposts' => 1, 'fields' => 'ids' ) );
			$image_id = $latest ? get_post_thumbnail_id( $latest[0] ) : 0;
		}
		$image = $image_id ? wp_get_attachment_image_src( $image_id, 'large' ) : false;
		if ( $image ) {
			printf( "<meta property=\"og:image\" content=\"%s\">\n", esc_url( $image[0] ) );
			echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		}

		if ( is_singular( 'post' ) ) {
			$data = array(
				'@context'         => 'https://schema.org',
				'@type'            => 'NewsArticle',
				'headline'         => get_the_title( $post ),
				'description'      => $desc,
				'inLanguage'       => 'en-GB',
				'datePublished'    => get_the_date( 'c', $post ),
				'dateModified'     => get_the_modified_date( 'c', $post ),
				'author'           => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', $post->post_author ) ),
				'mainEntityOfPage' => $url,
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
		}
	},
	5
);

// Tell the browser how wide each photograph is drawn, so it picks a file that stays sharp.
// A photograph that links to its article repeats the link of the title next to it, so it is
// taken out of the tab order and hidden from screen readers, and its alternative text is emptied.
// A photograph with a focal point carries it as a custom property that the stylesheet reads.
add_filter(
	'render_block_core/post-featured-image',
	static function ( $html, $block, $block_instance ) {
		if ( '' === trim( (string) $html ) ) {
			return $html;
		}
		$class   = $block['attrs']['className'] ?? '';
		$is_link = ! empty( $block['attrs']['isLink'] );
		$post_id = $block_instance->context['postId'] ?? get_the_ID();
		$focus   = $post_id ? accnews_image_focus( (int) get_post_thumbnail_id( $post_id ) ) : '';
		$tags    = new WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag() ) {
			$tag = $tags->get_tag();
			if ( 'A' === $tag && $is_link ) {
				$tags->set_attribute( 'tabindex', '-1' );
				$tags->set_attribute( 'aria-hidden', 'true' );
			}
			if ( 'IMG' !== $tag ) {
				continue;
			}
			if ( $is_link ) {
				$tags->set_attribute( 'alt', '' );
			}
			if ( '' !== $focus ) {
				$style = rtrim( (string) $tags->get_attribute( 'style' ), '; ' );
				$tags->set_attribute( 'style', ltrim( $style . ';--fb-focus:' . $focus . ';', ';' ) );
			}
			if ( str_contains( $class, 'is-hero' ) ) {
				// On a phone the picture is cropped to a square, so it is drawn one and a half times
				// as wide as the screen. On a wide screen it fills a panel about half as wide as the
				// window, but it is cropped to the height of that panel, so the whole picture is
				// drawn one and a half times as wide as the panel is tall.
				$tags->set_attribute( 'sizes', '(max-width: 599px) 150vw, (max-width: 899px) 100vw, min(84vw, 150vh - 14.25rem)' );
				$tags->set_attribute( 'loading', 'eager' );
				$tags->set_attribute( 'fetchpriority', 'high' );
			} elseif ( str_contains( $class, 'is-wide' ) ) {
				$tags->set_attribute( 'sizes', '(max-width: 1280px) 100vw, 1200px' );
				$tags->set_attribute( 'loading', 'eager' );
				$tags->set_attribute( 'fetchpriority', 'high' );
			} else {
				$tags->set_attribute( 'sizes', '(max-width: 699px) 100vw, 600px' );
			}
		}
		return $tags->get_updated_html();
	},
	10,
	3
);

// The header menu marks the page being read. Links written as plain addresses get no mark from
// WordPress, so the address of each link is compared with the address of the request.
add_filter(
	'render_block_core/navigation-link',
	static function ( $html, $block ) {
		$url = (string) ( $block['attrs']['url'] ?? '' );
		if ( '' === $url ) {
			return $html;
		}
		global $wp;
		$link = '/' . trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$here = '/' . trim( (string) ( $wp->request ?? '' ), '/' );
		$mark = '';
		if ( '/' === $link ) {
			if ( is_front_page() || ( is_home() && ! is_paged() ) ) {
				$mark = 'page';
			} elseif ( is_singular( 'post' ) || is_archive() || is_home() ) {
				// An article or a category belongs to the list of articles.
				$mark = 'true';
			}
		} elseif ( $link === $here && ! is_404() ) {
			$mark = 'page';
		}
		if ( '' === $mark ) {
			return $html;
		}
		$tags = new WP_HTML_Tag_Processor( $html );
		if ( $tags->next_tag( 'li' ) ) {
			$tags->add_class( 'page' === $mark ? 'current-menu-item' : 'current-menu-ancestor' );
		}
		if ( $tags->next_tag( 'a' ) ) {
			$tags->set_attribute( 'aria-current', $mark );
		}
		return $tags->get_updated_html();
	},
	10,
	2
);

// A category printed with the class "is-plain" is text, not a link. Inside a card the whole card
// already leads to the article, and a second small link there is hard to hit.
add_filter(
	'render_block_core/post-terms',
	static function ( $html, $block ) {
		if ( ! str_contains( (string) ( $block['attrs']['className'] ?? '' ), 'is-plain' ) ) {
			return $html;
		}
		return preg_replace( '~<a\b[^>]*>(.*?)</a>~s', '$1', (string) $html );
	},
	10,
	2
);

/**
 * Names the medium of each sample on the formats page, so the stylesheet can set each one in its
 * own material. A sample that holds an image card is a card, one with labels is a newsletter,
 * one that opens with a headline is an article and any other is a post for social media.
 */
function accnews_format_kinds( string $html ): string {
	$kinds = array();
	$index = -1;
	$first = false;
	$tags  = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		if ( $tags->has_class( 'fb-format__sample' ) ) {
			$kinds[ ++$index ] = 'is-social';
			$first             = true;
			continue;
		}
		if ( $index < 0 ) {
			continue;
		}
		if ( $tags->has_class( 'fb-card' ) ) {
			$kinds[ $index ] = 'is-card';
		} elseif ( $tags->has_class( 'fb-kicker' ) && 'is-card' !== $kinds[ $index ] ) {
			$kinds[ $index ] = 'is-newsletter';
		} elseif ( $first && $tags->has_class( 'fb-format__title' ) ) {
			$kinds[ $index ] = 'is-article';
		}
		$first = false;
	}
	if ( ! $kinds ) {
		return $html;
	}
	$index = 0;
	$tags  = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag( array( 'class_name' => 'fb-format__sample' ) ) ) {
		$tags->add_class( $kinds[ $index++ ] ?? 'is-social' );
	}
	return $tags->get_updated_html();
}

// Tables. Column headers get a scope, and a table with no caption takes its name from the
// subheading above it, so a screen reader can tell one table from the next.
add_filter(
	'the_content',
	static function ( $html ) {
		// In a sample of another format, a paragraph that is only a bold line is the headline of the sample.
		if ( str_contains( (string) $html, 'fb-format' ) ) {
			$titled = preg_replace(
				'~<p class="([^"]*)">(\s*<strong>(?:(?!</strong>).)*</strong>\s*)</p>~s',
				'<p class="$1 fb-format__title">$2</p>',
				(string) $html
			);
			$html   = null === $titled ? $html : $titled;
			$html   = accnews_format_kinds( (string) $html );
		}
		if ( ! str_contains( (string) $html, '<table' ) ) {
			return $html;
		}
		$heading = '';
		$pattern = '~<h([2-4])\b[^>]*>(.*?)</h\1>|<figure\b[^>]*\bwp-block-table\b[^>]*>.*?</figure>~s';
		$result  = preg_replace_callback(
			$pattern,
			static function ( array $m ) use ( &$heading ) {
				if ( ! empty( $m[1] ) ) {
					$heading = trim( wp_strip_all_tags( $m[2] ) );
					return $m[0];
				}
				$figure = preg_replace_callback(
					'~<thead\b.*?</thead>~s',
					static fn ( array $t ) => preg_replace( '~<th(?=[\s>])(?![^>]*\bscope=)~', '<th scope="col"', $t[0] ),
					$m[0]
				);
				// A first column that only holds numbers is an index, and it is set narrow.
				if ( preg_match_all( '~<tr>\s*<td[^>]*>(.*?)</td>~s', $figure, $cells ) && $cells[1] === preg_grep( '~^\s*\d{1,3}\.?\s*$~', $cells[1] ) ) {
					$figure = preg_replace( '~<figure\b([^>]*)\bclass="~', '<figure$1class="has-index ', $figure, 1 );
				}
				if ( ! str_contains( $figure, '<figcaption' ) && ! preg_match( '~<table\b[^>]*\baria-label(ledby)?=~', $figure ) ) {
					$label  = '' !== $heading ? $heading : wp_strip_all_tags( get_the_title() );
					$figure = preg_replace( '~<table\b~', '<table aria-label="' . esc_attr( $label ) . '"', $figure, 1 );
				}
				return $figure;
			},
			(string) $html
		);
		return null === $result ? $html : $result;
	},
	20
);

// Drawings. A graphic from the theme gets its width and height, so the page does not jump while
// it loads. When an SVG has a file with the same name ending in "-mobile" next to it, screens up
// to 899 pixels wide get that one, which is drawn taller and with larger lettering.
add_filter(
	'render_block_core/image',
	static function ( $html ) {
		if ( preg_match( '~<img\b[^>]*\bsrc="[^"]+/assets/graphics/([A-Za-z0-9_-]+\.(?:png|jpe?g|webp))"[^>]*>~', (string) $html, $m ) ) {
			$file = get_theme_file_path( 'assets/graphics/' . $m[1] );
			$box  = is_readable( $file ) ? getimagesize( $file ) : false;
			if ( ! $box || preg_match( '~\bwidth=~', $m[0] ) ) {
				return $html;
			}
			// These graphics sit well below the first screen, so they are not fetched until needed.
			$lazy = preg_match( '~\bloading=~', $m[0] ) ? '' : ' loading="lazy"';
			return str_replace( $m[0], preg_replace( '~<img\b~', sprintf( '<img width="%d" height="%d"%s', $box[0], $box[1], $lazy ), $m[0], 1 ), (string) $html );
		}
		if ( ! preg_match( '~<img\b[^>]*\bsrc="([^"]+/assets/graphics/([A-Za-z0-9_-]+)\.svg)"[^>]*>~', (string) $html, $m ) ) {
			return $html;
		}
		$size = static function ( string $name ): array {
			$file = get_theme_file_path( 'assets/graphics/' . $name . '.svg' );
			if ( ! is_readable( $file ) ) {
				return array();
			}
			$head = (string) file_get_contents( $file, false, null, 0, 600 );
			if ( preg_match( '~viewBox="\s*[\d.+-]+[\s,]+[\d.+-]+[\s,]+([\d.]+)[\s,]+([\d.]+)\s*"~', $head, $box ) ) {
				return array( (int) round( (float) $box[1] ), (int) round( (float) $box[2] ) );
			}
			return array();
		};
		list( $tag, $src, $name ) = $m;
		$wide = $size( $name );
		$img  = $tag;
		if ( $wide && ! preg_match( '~\bwidth=~', $tag ) ) {
			$img = preg_replace( '~<img\b~', sprintf( '<img width="%d" height="%d"', $wide[0], $wide[1] ), $tag, 1 );
		}
		$narrow = $size( $name . '-mobile' );
		if ( $narrow ) {
			$source = sprintf(
				'<source media="(max-width: 899px)" srcset="%s" width="%d" height="%d">',
				esc_url( substr( $src, 0, -4 ) . '-mobile.svg' ),
				$narrow[0],
				$narrow[1]
			);
			$img    = '<picture>' . $source . $img . '</picture>';
		}
		return str_replace( $tag, $img, (string) $html );
	}
);

// A pull quote that opens with a quotation mark hangs that mark outside the left edge of the text.
add_filter(
	'render_block_core/pullquote',
	static function ( $html ) {
		if ( ! preg_match( '~<p[^>]*>\s*(?:“|"|&#8220;|&ldquo;|«)~u', (string) $html ) ) {
			return $html;
		}
		$tags = new WP_HTML_Tag_Processor( (string) $html );
		if ( $tags->next_tag( 'figure' ) ) {
			$tags->add_class( 'has-open-quote' );
		}
		return $tags->get_updated_html();
	}
);

// A Query Loop marked with "excludeCurrent" leaves out the article being read.
add_filter(
	'query_loop_block_query_vars',
	static function ( array $query, $block ) {
		if ( ! empty( $block->context['query']['excludeCurrent'] ) && is_singular() ) {
			$query['post__not_in'] = array( get_queried_object_id() );
		}
		return $query;
	},
	10,
	2
);

add_filter( 'document_title_separator', static fn () => '|' );

// The standfirst is the excerpt. Never let WordPress append its own ellipsis link to it.
add_filter( 'excerpt_more', static fn () => '…' );
