<?php
/**
 * Title: About this sample
 * Slug: accnews/about
 * Categories: accnews
 * Description: A heading and a signature on the left and two paragraphs on the right.
 */
?>
<!-- wp:group {"align":"wide","className":"fb-about","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide fb-about"><!-- wp:group {"className":"fb-about__head","layout":{"type":"default"}} -->
<div class="wp-block-group fb-about__head"><!-- wp:heading -->
<h2 class="wp-block-heading">Why I made this site</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"fb-about__name"} -->
<p class="fb-about__name"><strong>Michael Cebral</strong><br>Science communicator</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"fb-about__text","layout":{"type":"default"}} -->
<div class="wp-block-group fb-about__text"><!-- wp:paragraph -->
<p>Accelerators are used for much more than particle physics. They work in hospitals, in industry and in the study of materials, and the technology inside them keeps improving. I find that fascinating, and I think more people would if someone explained it to them clearly.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>I am Michael Cebral, a science communicator with a background in biomedical research, and this sample is my way of showing how I would do it. I chose EPITA because it is a new project with a lot to tell, and I wrote every article from public sources, most of them published by CERN, the project and the European Commission.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"fb-link"} -->
<p class="fb-link"><a href="/about/">More about this sample</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
