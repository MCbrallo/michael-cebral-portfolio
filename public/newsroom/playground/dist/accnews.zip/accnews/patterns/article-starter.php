<?php
/**
 * Title: Article starter
 * Slug: accnews/article-starter
 * Categories: accnews
 * Description: The structure of a news article. Key points, body and sources.
 * Post Types: post
 */
?>
<!-- wp:group {"className":"is-style-brief","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-brief"><!-- wp:paragraph {"className":"fb-eyebrow"} -->
<p class="fb-eyebrow">Key points</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The single most important fact.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Who is involved and on what scale.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Why it matters outside the field.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p>Open with what happened. Keep the first paragraph to two or three sentences.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">A plain subheading</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Explain every technical term the first time it appears.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"fb-sources","layout":{"type":"default"}} -->
<div class="wp-block-group fb-sources"><!-- wp:paragraph {"className":"fb-eyebrow"} -->
<p class="fb-eyebrow">Sources</p>
<!-- /wp:paragraph -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li>Publisher, title and date, with a link.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group -->
