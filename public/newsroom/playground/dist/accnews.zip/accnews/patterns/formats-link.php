<?php
/**
 * Title: Link to the formats page
 * Slug: accnews/formats-link
 * Categories: accnews
 * Description: A heading, a line, the names of the four formats and the image card, which lead to the page where one story is told in four formats.
 */

// The card is read for its size, so the page keeps the right space for it if the file changes.
$accnews_card = (array) @getimagesize( get_theme_file_path( 'assets/graphics/linkedin-card.png' ) );
$accnews_card = array( (int) ( $accnews_card[0] ?? 2400 ), (int) ( $accnews_card[1] ?? 1254 ) );
?>
<!-- wp:group {"align":"wide","className":"fb-formats-link","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide fb-formats-link"><!-- wp:group {"className":"fb-formats-link__text","layout":{"type":"default"}} -->
<div class="wp-block-group fb-formats-link__text"><!-- wp:heading -->
<h2 class="wp-block-heading"><a href="/formats/">One story in four formats</a></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>One of these articles, told again for the newsletter and for social media. The facts stay the same and the writing changes with the reader.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"ordered":true,"className":"fb-formats-link__list"} -->
<ol class="wp-block-list fb-formats-link__list"><!-- wp:list-item -->
<li>News article</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Newsletter item</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>LinkedIn post</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Image card</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:html -->
<p class="fb-go" aria-hidden="true">See the four formats</p>
<!-- /wp:html --></div>
<!-- /wp:group -->

<!-- wp:html -->
<figure class="fb-formats-link__card"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/graphics/linkedin-card.png' ) ); ?>" alt="" width="<?php echo esc_attr( (string) $accnews_card[0] ); ?>" height="<?php echo esc_attr( (string) $accnews_card[1] ); ?>" loading="lazy" decoding="async"></figure>
<!-- /wp:html --></div>
<!-- /wp:group -->
