<?php
/**
 * Sample Newsroom content importer.
 *
 * Adapted from tools/seed.php of the site project so that it runs anywhere,
 * including WordPress Playground, where WordPress lives in /wordpress.
 * It reads seed.json and the media/ folder that sit next to this file.
 *
 * Ways to run it
 *   WordPress Playground, in a blueprint step:
 *     { "step": "runPHP", "code": "<?php require '/wordpress/wp-content/sample-newsroom-content/import.php';" }
 *   From a shell:
 *     php import.php /path/to/wordpress
 *   With WP-CLI:
 *     wp eval-file import.php
 *
 * It sets the site options, switches to the accnews theme when it is installed,
 * deletes every post, page and attachment (the default content of a new site
 * included), and inserts the articles with their featured images, the two pages
 * and the categories. It can be run again and gives the same result.
 * It stops with an error when something it needs is missing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	$sn_candidates = array();
	if ( 'cli' === PHP_SAPI && ! empty( $argv[1] ) ) {
		$sn_candidates[] = rtrim( $argv[1], '/' ) . '/wp-load.php';
	}
	if ( getenv( 'WP_ROOT' ) ) {
		$sn_candidates[] = rtrim( getenv( 'WP_ROOT' ), '/' ) . '/wp-load.php';
	}
	// A copy unpacked inside a WordPress folder finds that WordPress.
	for ( $sn_dir = __DIR__; dirname( $sn_dir ) !== $sn_dir; $sn_dir = dirname( $sn_dir ) ) {
		$sn_candidates[] = $sn_dir . '/wp-load.php';
	}
	$sn_candidates[] = '/wordpress/wp-load.php'; // WordPress Playground.
	$sn_load         = '';
	foreach ( $sn_candidates as $sn_candidate ) {
		if ( is_file( $sn_candidate ) ) {
			$sn_load = $sn_candidate;
			break;
		}
	}
	if ( '' === $sn_load ) {
		throw new RuntimeException( 'Sample Newsroom import: wp-load.php not found. Usage: php import.php /path/to/wordpress' );
	}
	// tools/seed.php sets HTTP_HOST and REQUEST_URI here. This file must not: WordPress
	// Playground takes a request address as a visitor to log in, answers with a
	// redirect and ends the script before anything is imported.
	require $sn_load;
}

require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';

/**
 * Runs the import. Everything lives in one function so that no variable leaks
 * into the scope that includes this file.
 *
 * @param string $content_dir Folder that holds seed.json and media/.
 */
function sample_newsroom_import( string $content_dir ): void {
	global $wp_rewrite;

	$fail = static function ( string $message ): void {
		throw new RuntimeException( 'Sample Newsroom import: ' . $message );
	};

	$seed_file = $content_dir . '/seed.json';
	$media_dir = $content_dir . '/media';
	if ( ! is_readable( $seed_file ) ) {
		$fail( "cannot read $seed_file" );
	}
	$data = json_decode( (string) file_get_contents( $seed_file ), true );
	if ( ! is_array( $data ) || empty( $data['posts'] ) || ! isset( $data['about'], $data['formats'] ) ) {
		$fail( 'seed.json does not hold posts, about and formats' );
	}
	foreach ( $data['posts'] as $post ) {
		if ( ! empty( $post['image'] ) && ! is_readable( $media_dir . '/' . $post['image'][0] ) ) {
			$fail( 'missing media file ' . $post['image'][0] );
		}
	}

	// ---------------------------------------------------------------- options
	update_option( 'blogname', 'Sample Newsroom' );
	update_option( 'blogdescription', 'Accelerator technology news. A work sample by Michael Cebral' );
	update_option( 'timezone_string', 'Europe/Madrid' );
	update_option( 'date_format', 'j F Y' );
	update_option( 'default_comment_status', 'closed' );
	update_option( 'default_ping_status', 'closed' );
	update_option( 'show_on_front', 'posts' );
	update_option( 'posts_per_page', 10 );
	wp_update_user(
		array(
			'ID'           => 1,
			'display_name' => 'Michael Cebral',
			'nickname'     => 'Michael Cebral',
			'first_name'   => 'Michael',
			'last_name'    => 'Cebral',
		)
	);

	if ( wp_get_theme( 'accnews' )->exists() ) {
		switch_theme( 'accnews' );
	} else {
		echo "warning: theme accnews is not installed, the active theme was left as it is\n";
	}

	// Start from a clean slate so the script can be run again. On a new site this
	// removes the default post, its comment, the sample page and the privacy draft.
	$old_posts = get_posts(
		array(
			'post_type'   => array( 'post', 'page', 'attachment' ),
			'numberposts' => -1,
			'post_status' => array( 'publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit', 'trash' ),
		)
	);
	foreach ( $old_posts as $old ) {
		wp_delete_post( $old->ID, true );
	}

	$wp_rewrite->set_permalink_structure( '/%postname%/' );

	// ---------------------------------------------------------------- articles
	$when = strtotime( '2026-11-12 07:00:00' );
	foreach ( get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) ) as $term ) {
		if ( 'news' !== $term->slug && 'uncategorized' !== $term->slug ) {
			wp_delete_term( $term->term_id, 'category' );
		}
	}
	foreach ( array_reverse( $data['posts'] ) as $i => $post ) {
		$cat = get_cat_ID( $post['category'] );
		if ( ! $cat ) {
			$cat = wp_create_category( $post['category'] );
		}
		$id = wp_insert_post(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'post_author'    => 1,
				'post_name'      => $post['slug'],
				'post_title'     => $post['title'],
				'post_excerpt'   => $post['excerpt'],
				'post_content'   => $post['content'],
				'post_category'  => array( $cat ),
				'post_date'      => gmdate( 'Y-m-d H:i:s', $when + $i * 3600 ),
				'comment_status' => 'closed',
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			$fail( "post {$post['slug']}: " . $id->get_error_message() );
		}
		echo "post $id {$post['slug']}\n";

		if ( empty( $post['image'] ) ) {
			continue;
		}
		list( $file, $alt, $caption ) = $post['image'];
		$upload = wp_upload_bits( $file, null, (string) file_get_contents( $media_dir . '/' . $file ) );
		if ( ! empty( $upload['error'] ) ) {
			$fail( "upload of $file: " . $upload['error'] );
		}
		$type = wp_check_filetype( $file );
		$att  = wp_insert_attachment(
			array(
				'post_mime_type' => $type['type'] ? $type['type'] : 'image/jpeg',
				'post_title'     => $alt,
				'post_excerpt'   => $caption,
				'post_status'    => 'inherit',
			),
			$upload['file'],
			$id,
			true
		);
		if ( is_wp_error( $att ) ) {
			$fail( "attachment $file: " . $att->get_error_message() );
		}
		wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $upload['file'] ) );
		update_post_meta( $att, '_wp_attachment_image_alt', $alt );
		set_post_thumbnail( $id, $att );
		echo "  image $att $file\n";
	}

	// ---------------------------------------------------------------- pages
	$about = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_author'  => 1,
			'post_name'    => 'about',
			'post_title'   => 'About this sample',
			'post_content' => $data['about'],
		),
		true
	);
	if ( is_wp_error( $about ) ) {
		$fail( 'page about: ' . $about->get_error_message() );
	}
	echo "page $about about\n";

	$formats = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_author'  => 1,
			'post_name'    => 'formats',
			'post_title'   => 'One story in four formats',
			'post_excerpt' => 'The story about permanent magnets as a news article, a newsletter item, a LinkedIn post and an image card.',
			'post_content' => $data['formats'],
		),
		true
	);
	if ( is_wp_error( $formats ) ) {
		$fail( 'page formats: ' . $formats->get_error_message() );
	}
	echo "page $formats formats\n";

	// The default category would otherwise show as an empty section.
	$uncat = get_cat_ID( 'Uncategorized' );
	if ( $uncat ) {
		wp_update_term( $uncat, 'category', array( 'name' => 'News', 'slug' => 'news' ) );
	}

	$wp_rewrite->flush_rules( false );
	echo 'theme: ' . wp_get_theme()->get( 'Name' ) . ' ' . wp_get_theme()->get( 'Version' ) . "\n";
	echo 'home: ' . home_url( '/' ) . "\n";
}

sample_newsroom_import( __DIR__ );
